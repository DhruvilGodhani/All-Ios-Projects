//
//  StudentModel.swift
//  FormInputWithCoreData
//
//  Created by Mobile5 on 28/11/24.
//

import Foundation
struct StudentModel : Codable{
    let id : Int
    let name : String
    let email: String
    let stream : String
   
}
