//
//  ViewController.swift
//  FormInputWithCoreData
//
//  Created by Mobile5 on 28/11/24.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    
    @IBOutlet weak var idTxt: UITextField!
    @IBOutlet weak var nameTxt: UITextField!
    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var streamTxt: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func movetoreadvc(_ sender: Any) {
        performSegue(withIdentifier: "navigate", sender: self)
    }
    

    @IBAction func savetocoredata(_ sender: Any) {
        
        guard let id = idTxt.text, !id.isEmpty,
            let name = nameTxt.text, !name.isEmpty,
                let email = emailTxt.text, !email.isEmpty,
                let stream = streamTxt.text, !stream.isEmpty
                
                
        else{
            let alert = UIAlertController(title: "Error", message: "All Fields are required", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            present(alert,animated: true , completion: nil)
            return
        }
        let idInt  = Int(id)
        
        addToCoreData(dataObject: StudentModel(id: idInt!, name: name, email: email, stream: stream))
        
    }
    
    
    func addToCoreData(dataObject: StudentModel){
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let managedContext = delegate.persistentContainer.viewContext
                
        guard let jokeEntity = NSEntityDescription.entity(forEntityName: "Student", in: managedContext) else {return}
        
        let student = NSManagedObject(entity: jokeEntity, insertInto: managedContext)
        
        student.setValue(dataObject.id, forKey: "id")
        student.setValue(dataObject.name, forKey: "name")
        student.setValue(dataObject.email, forKey: "email")
        student.setValue(dataObject.stream, forKey: "stream")
        
        
        do{
            try managedContext.save()
            debugPrint("Data Saved")
            
            let alert = UIAlertController(title: "Success", message: "Data Saved Suceessfully.!", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            present(alert,animated: true , completion: nil)
        }
        catch let err as NSError{
            debugPrint("Error occured: \(err.self)")
        }
        
    }
}

