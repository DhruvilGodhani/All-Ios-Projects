//
//  Holiday.swift
//  HolidaysAPI
//
//  Created by ADMIN on 09/10/24.
//

import Foundation
public struct Holiday: Codable{
    let date:String;
    let localName:String;
    let countryCode:String;
}
