//
//  ViewController.swift
//  HolidaysAPI
//
//  Created by ADMIN on 09/10/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    

    @IBOutlet weak var table: UITableView!
    private var holidays: [Holiday] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        table.dataSource = self
        table.delegate = self
        table.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell")
        fetchData { result in
            switch result{
            case .success(let data):
                self.holidays.append(contentsOf: data)
                self.table.reloadData()
            case .failure(let error):
                debugPrint("Something went wrong...")
            }
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.holidays.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        cell.date.text = holidays[indexPath.row].date
        cell.localName.text = holidays[indexPath.row].localName
        cell.countryCOde.text = holidays[indexPath.row].countryCode
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            holidays.remove(at: indexPath.row)
            table.deleteRows(at: [indexPath], with: .left)
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        // Fetch the selected holiday
        let selectedHoliday = holidays[indexPath.row]
        
        // Encode the Holiday object to Data
        do {
            let encoder = JSONEncoder()
            let holidayData = try encoder.encode(selectedHoliday)
            UserDefaults.standard.set(holidayData, forKey: "selectedHoliday")
            
            // Perform the segue
            performSegue(withIdentifier: "toDisplay", sender: self)
        } catch {
            print("Failed to encode Holiday: \(error)")
        }
    }

    
}

