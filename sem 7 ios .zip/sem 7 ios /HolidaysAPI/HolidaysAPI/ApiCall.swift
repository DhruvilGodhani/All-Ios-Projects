//
//  ApiCall.swift
//  HolidaysAPI
//
//  Created by ADMIN on 09/10/24.
//

import Foundation
import Alamofire

func fetchData(completionHandler: @escaping(Result<[Holiday], Error>) -> Void){
    let url:String = "https://date.nager.at/api/v2/publicholidays/2020/US"
    AF.request(url).responseDecodable(of:[Holiday].self){
        response in
        switch response.result{
        case .success(let data):
            completionHandler(.success(data))
        case .failure(let error):
            completionHandler(.failure(error))
        }
    }
}
