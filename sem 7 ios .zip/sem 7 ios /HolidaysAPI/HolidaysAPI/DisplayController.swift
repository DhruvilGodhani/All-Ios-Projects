import UIKit

class DisplayController: UIViewController {

    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var localName: UILabel!
    @IBOutlet weak var countryCode: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Attempt to retrieve and decode the selected holiday from UserDefaults
        if let savedHolidayData = UserDefaults.standard.data(forKey: "selectedHoliday") {
            do {
                // Decode the data into a Holiday object
                let decoder = JSONDecoder()
                let selectedHoliday = try decoder.decode(Holiday.self, from: savedHolidayData)
                
                // Use the selected holiday data
                date.text = selectedHoliday.date
                localName.text = selectedHoliday.localName
                countryCode.text = selectedHoliday.countryCode
            } catch {
                print("Failed to decode Holiday: \(error)")
            }
        } else {
            print("No selected holiday found in UserDefaults.")
        }
    }
}
