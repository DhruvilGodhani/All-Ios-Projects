//
//  ViewController.swift
//  CatCalling
//
//  Created by ADMIN on 09/10/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var table: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

