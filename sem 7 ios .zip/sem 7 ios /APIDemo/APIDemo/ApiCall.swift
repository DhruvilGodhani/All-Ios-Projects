//
//  ApiCall.swift
//  APIDemo
//
//  Created by ADMIN on 09/12/24.
//

import Foundation
import Alamofire

func ApiCall(cv: @escaping(Result<[jokeModel],Error>)->Void){
    let url = "https://official-joke-api.appspot.com/jokes/random/25"
    AF.request(url).responseDecodable(of: [jokeModel].self){
        response in
        switch response.result {
            case .success(let Data) :
            cv(.success(Data))
            case  .failure(let err) :
            cv(.failure(err))
        }
    }
}
