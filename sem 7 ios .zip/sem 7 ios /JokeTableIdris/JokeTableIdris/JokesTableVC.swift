//
//  JokesTableVC.swift
//  tableIdris
//
//  Created by ADMIN on 17/09/24.
//

import Foundation
import UIKit

class JokesTableVC: UIViewController{
    private var jokes: [JokeModel] = []
    
    @IBOutlet var table: UITableView!
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getJokes()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTable()
       
    }

    
    func setupTable(){
        table.register(UINib(nibName: "JokeCell", bundle: nil), forCellReuseIdentifier: "JokeCell")
        table.dataSource = self
        table.delegate = self
    }
    
    func reloadTable(){
        DispatchQueue.main.async {
            self.table.reloadData()

        }
    }
    func getJokes(){
        ApiManager().fetchJokesAF{
            result in switch result{
            case .success(let data):
                self.jokes.append(contentsOf: data)
                self.reloadTable()
            case .failure(let error):
                debugPrint("Something went wrong..")
            }
        }
    }
}
//  MARK: - tableview methods
extension JokesTableVC: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return jokes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "JokeCell", for: indexPath) as! JokeCell
        cell.label.text = jokes[indexPath.row].setup
        
        return cell
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            jokes.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
}
