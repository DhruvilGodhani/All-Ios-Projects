//
//  ApiManager.swift
//  DhruvilIsAJoke
//
//  Created by ADMIN on 29/09/24.
//

import Foundation
import Alamofire

class ApiManager{
    let url: String = "https://official-joke-api.appspot.com/jokes/random/25"
    var jokesRespone: [JokeModel] = []
    func fetchJokesAF(completionHandler: @escaping(Result<[JokeModel], Error>) -> Void){
        AF.request(url).responseDecodable(of: [JokeModel].self){ response in
            switch response.result{
            case .success(let data):
                completionHandler(.success(data))
            case .failure(let error):
                completionHandler(.failure(error))
            }
            
        }
    }
    
}

