//
//  QuoteModel.swift
//  FightAddictionsSegment
//
//  Created by ADMIN on 05/12/24.
//

import Foundation
public struct QuoteModel: Codable {
    let id: Int64
    let quote: String
}
