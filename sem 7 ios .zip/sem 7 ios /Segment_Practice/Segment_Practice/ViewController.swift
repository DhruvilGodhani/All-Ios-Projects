//
//  ViewController.swift
//  Segment_Practice
//
//  Created by ADMIN on 04/12/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        <#code#>
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        <#code#>
    }
    

    @IBOutlet weak var segment: UISegmentedControl!
    @IBOutlet weak var firstTable: UITableView!
    @IBOutlet weak var secondTable: UITableView!
    var jokes : [Model] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        segment.selectedSegmentIndex = 0
        firstTable.delegate = self
        firstTable.dataSource = self
        
        secondTable.delegate = self
        secondTable.dataSource = self
        // Do any additional setup after loading the view.
    }

    @IBAction func changeSegment(_ sender: Any) {
        
    }
    
}

