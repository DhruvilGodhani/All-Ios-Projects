//
//  Model.swift
//  Segment_Practice
//
//  Created by ADMIN on 04/12/24.
//

import Foundation
import Alamofire

struct Model: Codable{
    let id: Int
    let type: String
    let setup: String
    let punchline: String
}
