//
//  ViewController.swift
//  SliderDemo
//
//  Created by ADMIN on 09/12/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var opacitySlider: UISlider!
    @IBOutlet weak var bslider: UISlider!
    @IBOutlet weak var gslider: UISlider!
    @IBOutlet weak var rslider: UISlider!
    @IBOutlet weak var ColoeView: UIView!
    
    @IBOutlet var mainView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func SliderBtn(_ sender: Any) {
        var r = CGFloat(rslider.value)
        var g = CGFloat(gslider.value)
        var b = CGFloat(bslider.value)
        var o = CGFloat(opacitySlider.value)
        mainView.backgroundColor = UIColor(red:r/255,green:g/255,blue:b/255,alpha:o)

    }
    
    func chnageColor(r:CGFloat,g:CGFloat,b:CGFloat,o:CGFloat){
            ColoeView.backgroundColor = UIColor(red:r/255,green:g/255,blue:b/255,alpha:o)
    }
    
    @IBAction func rsliderLayout(_ sender: Any) {
        var r = CGFloat(rslider.value)
        var g = CGFloat(gslider.value)
        var b = CGFloat(bslider.value)
        var o = CGFloat(opacitySlider.value)
        chnageColor(r: r, g: g, b: b, o: o)

    }
    
    
    @IBAction func gsliderLayout(_ sender: Any) {
        var r = CGFloat(rslider.value)
        var g = CGFloat(gslider.value)
        var b = CGFloat(bslider.value)
        var o = CGFloat(opacitySlider.value)
        chnageColor(r: r, g: g, b: b, o: o)

    }
    
    
    @IBAction func bsliderLayout(_ sender: Any) {
        var r = CGFloat(rslider.value)
        var g = CGFloat(gslider.value)
        var b = CGFloat(bslider.value)
        var o = CGFloat(opacitySlider.value)
        chnageColor(r: r, g: g, b: b, o: o)

    }
    
    
    @IBAction func opacityLayout(_ sender: Any) {
        var r = CGFloat(rslider.value)
        var g = CGFloat(gslider.value)
        var b = CGFloat(bslider.value)
        var o = CGFloat(opacitySlider.value)
        chnageColor(r: r, g: g, b: b, o: o)

    }
}

