//
//  ApiService.swift
//  CatApi
//
//  Created by ADMIN on 07/10/24.
//

import Foundation
import Alamofire

class CatBreedService {
    func fetchCatBreeds(completion: @escaping ([CatBreed]?) -> Void) {
        let url = "https://freetestapi.com/api/v1/cats?limit=5" // Replace with your API endpoint

        AF.request(url).responseDecodable(of: [CatBreed].self) { response in
            switch response.result {
            case .success(let catBreeds):
                completion(catBreeds)
            case .failure(let error):
                print("Error fetching data: \(error)")
                completion(nil)
            }
        }
    }
}

