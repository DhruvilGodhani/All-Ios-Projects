//
//  User.swift
//  CoreDataDemo2
//
//  Created by ADMIN on 24/09/24.
//

import Foundation
struct UserModel: Codable{
    let id: Int
    let name: String
    let email: String
    
}
