//
//  ViewController.swift
//  Slider
//
//  Created by ADMIN on 09/12/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Colorview: UIView!
    @IBOutlet weak var opacitySlider: UISlider!
    @IBOutlet weak var bSlider: UISlider!
    @IBOutlet weak var gSlider: UISlider!
    @IBOutlet weak var rSlider: UISlider!
    @IBOutlet weak var mainview: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    func Changecolor(r:CGFloat,g:CGFloat,b:CGFloat,o:CGFloat){
        Colorview.backgroundColor = UIColor(red:r/255,green:g/255,blue:b/255,alpha:o)
    }

    @IBAction func chnagecolorAction(_ sender: Any) {
        var r = CGFloat(rSlider.value)
        var g = CGFloat(gSlider.value)
        var b = CGFloat(bSlider.value)
        var o = CGFloat(opacitySlider.value)
        mainview.backgroundColor = UIColor(red:r/255,green:g/255,blue:b/255,alpha:o)

    }
    
    @IBAction func rSliderAction(_ sender: Any) {
        var r = CGFloat(rSlider.value)
        var g = CGFloat(gSlider.value)
        var b = CGFloat(bSlider.value)
        var o = CGFloat(opacitySlider.value)
        Changecolor(r: r, g: g, b: b, o: o )
    }
    
    @IBAction func gSliderAction(_ sender: Any) {
        var r = CGFloat(rSlider.value)
        var g = CGFloat(gSlider.value)
        var b = CGFloat(bSlider.value)
        var o = CGFloat(opacitySlider.value)
        Changecolor(r: r, g: g, b: b, o: o )
    }
    
    @IBAction func opacitySliderAction(_ sender: Any) {
        var r = CGFloat(rSlider.value)
        var g = CGFloat(gSlider.value)
        var b = CGFloat(bSlider.value)
        var o = CGFloat(opacitySlider.value)
        Changecolor(r: r, g: g, b: b, o: o )
    }
}

