//
//  UpdateVC.swift
//  Update_Data
//
//  Created by ADMIN on 07/12/24.
//

import UIKit

class UpdateVC: UIViewController {

    @IBAction func name(_ sender: Any) {
    }
    @IBAction func author(_ sender: Any) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func updateBtn(_ sender: Any) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
