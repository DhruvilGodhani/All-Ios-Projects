//
//  ViewController.swift
//  BrandNewProject
//
//  Created by ADMIN on 03/10/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var input: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnPress(_ sender: Any) {
        UserDefaults.standard.setValue(input.text, forKey: "UserName")
        performSegue(withIdentifier: "GoToShowScreen", sender: self)
    }
    
}

