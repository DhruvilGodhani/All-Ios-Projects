//
//  gridCell.swift
//  collection_view_task
//
//  Created by ADMIN on 16/08/24.
//

import UIKit

class gridCell: UICollectionViewCell {
    
    
}
